import React, { useState, useEffect } from 'react';
import { MainLayout } from '../layouts/MainLayout';
import api from '../api/client';
import { Mail, CheckCircle, XCircle, Search, RefreshCw } from 'lucide-react';
import { Button } from '../components/Button';

export const Emails = () => {
    const [emails, setEmails] = useState([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');

    useEffect(() => {
        fetchEmails();
    }, []);

    const fetchEmails = async () => {
        setLoading(true);
        try {
            const res = await api.get('/api/admin/communication/emails');
            setEmails(res.data);
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    const filteredEmails = emails.filter(e =>
        (e.recipient || '').toLowerCase().includes(search.toLowerCase()) ||
        (e.recipientEmail || '').toLowerCase().includes(search.toLowerCase()) ||
        (e.subject || '').toLowerCase().includes(search.toLowerCase())
    );

    return (
        <MainLayout title="Email Logs">
            <div className="flex flex-col gap-6">

                <div className="flex justify-between items-center bg-white p-4 rounded-xl shadow-sm">
                    <div className="flex items-center gap-3 bg-slate-50 px-4 py-2.5 rounded-lg border border-slate-200">
                        <Search size={18} className="text-slate-400" />
                        <input
                            type="text"
                            placeholder="Search logs..."
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            className="bg-transparent border-none outline-none text-sm w-64"
                        />
                    </div>
                    <Button variant="secondary" onClick={fetchEmails} disabled={loading}>
                        <RefreshCw size={18} className={loading ? "animate-spin" : ""} />
                        Refresh
                    </Button>
                </div>

                <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                    <div className="grid grid-cols-[1.5fr_1.5fr_2fr_3fr_1fr] bg-slate-50 border-b border-slate-200 px-6 py-3">
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Date</span>
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Recipient</span>
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Subject</span>
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Message Snippet</span>
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider text-center">Status</span>
                    </div>

                    <div className="divide-y divide-slate-100">
                        {filteredEmails.length === 0 ? (
                            <div className="p-8 text-center text-slate-400">No emails found.</div>
                        ) : (
                            filteredEmails.map(email => (
                                <div key={email.id} className="grid grid-cols-[1.5fr_1.5fr_2fr_3fr_1fr] px-6 py-4 items-center hover:bg-slate-50 transition-colors">
                                    <span className="text-sm font-medium text-slate-600">{email.date}</span>
                                    <div className="flex flex-col">
                                        <span className="text-sm font-bold text-slate-800">{email.recipient}</span>
                                        <span className="text-xs text-slate-500">{email.recipientEmail}</span>
                                    </div>
                                    <span className="text-sm font-medium text-indigo-600 truncate pr-4">{email.subject}</span>
                                    <span className="text-sm text-slate-500 truncate pr-4">{email.message}</span>
                                    <div className="flex justify-center">
                                        {email.status === 'Sent' ? (
                                            <span className="flex items-center gap-1 text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full border border-emerald-100">
                                                <CheckCircle size={12} /> Sent
                                            </span>
                                        ) : (
                                            <span className="flex items-center gap-1 text-xs font-bold text-red-600 bg-red-50 px-2 py-1 rounded-full border border-red-100">
                                                <XCircle size={12} /> Failed
                                            </span>
                                        )}
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>
        </MainLayout>
    );
};
